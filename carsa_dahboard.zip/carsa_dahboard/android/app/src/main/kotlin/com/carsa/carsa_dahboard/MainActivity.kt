package com.carsa.carsa_dahboard

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
