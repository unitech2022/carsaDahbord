package com.example.flutter_web_test

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
