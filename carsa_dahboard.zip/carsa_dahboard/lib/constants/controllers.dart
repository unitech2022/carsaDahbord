

import '../controllers/menu_controller.dart';
import '../controllers/navigation_controller.dart';

MenuControllerGet menuController = MenuControllerGet.instance;
NavigationController navigationController = NavigationController.instance;