
  const baseUrl="http://localhost:5000/";

//  const baseUrl = "https://carsa.urapp.site/";

const baseUrlImages=baseUrl+"images/";
// work shop

const getWorkshopsByCatIdPath = baseUrl+"workshops/get-workshop-by-CatI-admin?";
const getCategoriesWorkshopsPath = baseUrl+"category/get-categories-work";
const getPostsPath = baseUrl+"post/get-Posts-admin";











