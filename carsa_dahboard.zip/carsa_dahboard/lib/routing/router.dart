import 'package:flutter/material.dart';
import 'package:carsa_dahboard/pages/brands_screen/brands_screen.dart';
import 'package:carsa_dahboard/pages/category_screen/drivers.dart';

import 'package:carsa_dahboard/pages/clients/clients.dart';
import 'package:carsa_dahboard/pages/orders_screen/orders_screen.dart';

import 'package:carsa_dahboard/pages/overview/overview.dart';
import 'package:carsa_dahboard/pages/posts_screen/posts_screen.dart';
import 'package:carsa_dahboard/pages/products_screen/products_screen.dart';
import 'package:carsa_dahboard/pages/siting_screen/siting_screen.dart';
import 'package:carsa_dahboard/pages/slider_screen/sliders_screen.dart';
import 'package:carsa_dahboard/pages/suggestses_screen/suggestses_screen.dart';
import 'package:carsa_dahboard/pages/workshops_page/workshops_page.dart';
import 'package:carsa_dahboard/routing/routes.dart';

import '../pages/car_models_screen/car_models_screen.dart';
import '../pages/supports_screen/supports_screen.dart';



Route<dynamic> generateRoute(RouteSettings settings){
  switch (settings.name) {
    case overviewPageRoute:
      return _getPageRoute(OverviewPage());
    case driversPageRoute:
      return _getPageRoute(DriversPage());
    case productsPageRoute:
      return _getPageRoute(ProductsScreen());
    case brandsPageRoute:
      return _getPageRoute(BrandsScreen());
          case carModelsPageRoute:
      return _getPageRoute(CarModelsScreen());
    case slidersPageRoute:
      return _getPageRoute(SlidersScreen());
    case ordersPageRoute:
      return _getPageRoute(OrdersScreen());

    case workshopsPageRoute:
      return _getPageRoute(WorkshopsScreen());

      case postsPageRoute:
      return _getPageRoute(PostsScreen());

    case clientsPageRoute:
      return _getPageRoute(ClientsPage());
    case suggestionsPageRoute:
      return _getPageRoute(SuggestionsScreen());

    case sittingPageRoute:
      return _getPageRoute(SittingScreen());

    case messagesPageRoute:
      return _getPageRoute(SupportsScreen());
    default:
      return _getPageRoute(OverviewPage());

  }
}

PageRoute _getPageRoute(Widget child){
  return MaterialPageRoute(builder: (context) => child);
}